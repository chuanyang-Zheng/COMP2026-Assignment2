import java.util.Scanner;
public class test {
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        if(in.nextInt()==123)
            System.out.println(in.nextInt());
        String[][] x=new String[1][1];
        x[0][0]="";
        if(x[0][0].equals(""));
        System.out.println("xxx");
        Scanner inf=new Scanner("AAAAAAAA aaaaaaaaa");
        System.out.println(inf.next());
    }
}
