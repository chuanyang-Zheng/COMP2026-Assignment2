1.Failing to open an input file 
     Note: this will not make errors any more
2.Failing to open an output file
     Note: this will not makes errors any more
3.Errors happening when performing file IO operations
     Note: this will not make errors any more
4.Corrupted data in the input files:(1) ID length not correct
                                                      (2) gender
                                                      (3) line with nothing
                                                      (4) time is not correct. For example,  X200
      Note: this will not makes errors any more

Actually, this program will never stop only if you give command "quit"

Please run "Run.java" to run the program


Student: 17251311
